package gui;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JTable;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JScrollPane;
import javax.swing.table.DefaultTableModel;

public class Cost extends JFrame {

	private JPanel contentPane;
	private JTable costFields;
	private JTextField textField;
	private JScrollPane scrollPane;

	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Cost frame = new Cost();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	public Cost() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 626, 355);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		scrollPane = new JScrollPane();
		scrollPane.setBounds(40, 132, 543, 166);
		contentPane.add(scrollPane);
		
		costFields = new JTable();
		costFields.setModel(new DefaultTableModel(
			new Object[][] {
			},
			new String[] {
				"Algorithms Used ", "Cost"
			}
		));
		costFields.getColumnModel().getColumn(0).setPreferredWidth(119);
		scrollPane.setViewportView(costFields);
		
		JLabel costPageTitle = new JLabel("Cost Estimation");
		costPageTitle.setFont(new Font("Times New Roman", Font.BOLD, 25));
		costPageTitle.setBounds(210, 35, 189, 40);
		contentPane.add(costPageTitle);
		
		textField = new JTextField();
		textField.setEditable(false);
		textField.setBounds(128, 101, 445, 20);
		contentPane.add(textField);
		textField.setColumns(10);
		
		JLabel query = new JLabel("Query");
		query.setFont(new Font("Tahoma", Font.PLAIN, 15));
		query.setBounds(52, 101, 48, 17);
		contentPane.add(query);
	}
}
